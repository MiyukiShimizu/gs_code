<?php
//kadai_insert.phpから作成
//1. POSTデータ取得(飛んできたのを受け取る)
$name   = $_POST["name"];
$category = $_POST["category"];
$url  = $_POST["url"];
$comment = $_POST["comment"];
$id = $_POST["id"];

//2. DB接続します
include("kadai_funcs.php");
$pdo = db_conn();

//３．データ登録SQL作成
//prepareはSQLを読む関数
$stmt = $pdo->prepare("UPDATE gs_bm_table SET name=:name,category=:category,url=:url,comment=:comment  WHERE id=:id");
$stmt->bindValue(':name', $name, PDO::PARAM_STR); 
$stmt->bindValue(':category', $category, PDO::PARAM_STR);
$stmt->bindValue(':url', $url, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':comment', $comment, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':id', $id, PDO::PARAM_INT);  //Integer（数値の場合 PDO::PARAM_INT)
$status = $stmt->execute();

//４．データ登録処理後
if($status==false){
  sql_error();

}else{
  redirect("kadai_select.php");
  
}
?>
