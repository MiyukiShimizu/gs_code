<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>通知データベース</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <style>div{padding: 10px;font-size:16px;}</style>
</head>
<body>

<!-- Head[Start] -->
<header>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
    <div class="navbar-header"><a class="navbar-brand" href="kadai_select.php">通知一覧</a></div>
    </div>
  </nav>
</header>
<!-- Head[End] -->

<!-- Main[Start] -->
<form method="POST" action="kadai_insert.php">
  <div class="jumbotron">
   <fieldset>
    <legend>通知データベース</legend>
     <label>通知名：<input type="text" name="name"></label><br>
     <label>カテゴリー：<input type="text" name="category"></label><br>
     <label>格納URL：<input type="text" name="url"></label><br>
     <label>備考<textArea name="comment" rows="4" cols="40"></textArea></label><br>
     <input type="submit" value="送信">
    </fieldset>
  </div>
</form>
<!-- Main[End] -->


</body>
</html>
