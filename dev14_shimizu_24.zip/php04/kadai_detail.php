<?php
//1. insert.phpのコピペ(データベースからデータを引き出す)
$id = $_GET["id"];

//2. DB接続します
include("kadai_funcs.php");
$pdo = db_conn();


//３．データ登録SQL作成
//prepareはSQLを読む関数
$stmt = $pdo->prepare("SELECT * FROM gs_bm_table WHERE id=:id");
$stmt->bindValue(":id", $id, PDO::PARAM_INT); 
$status = $stmt->execute();

//４．データ登録処理後
if($status==false){
    sql_error();
  
}else{
  $row = $stmt->fetch();
}
?>
