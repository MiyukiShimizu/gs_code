<?php
$pw=password_hash("test2", PASSWORD_DEFAULT);
echo $pw;