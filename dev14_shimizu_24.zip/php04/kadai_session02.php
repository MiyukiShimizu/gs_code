<!-- サーバーに取りに行く変数 -->
<?php
session_start();
// echo $_SESSION["name1"];
// echo $_SESSION["name2"];
echo session_id();
//ここで表示されるのは、cookieのキーを示している。サーバーが準備したキーなので、個々を判断できる。
//セッションを一度スタートしたら、終了（ログアウトかブラウザを切る）するまで同じキーを使う。
