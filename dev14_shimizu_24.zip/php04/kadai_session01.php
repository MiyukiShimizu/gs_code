<!-- サーバーに挙げるための変数 -->
<?php
session_start();
$_SESSION["name1"]="Shimizu";
$_SESSION["name2"]="YAMAZAKI";