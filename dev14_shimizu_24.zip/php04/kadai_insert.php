<?php
//1. POSTデータ取得(飛んできたのを受け取る)
$name   = $_POST["name"];
$category = $_POST["category"];
$url  = $_POST["url"];
$comment = $_POST["comment"];

//2. DB接続します
include("kadai_funcs.php");
$pdo = db_conn();

//３．データ登録SQL作成
//prepareはSQLを読む関数
$stmt = $pdo->prepare("INSERT INTO gs_bm_table(name, category, url, comment, date)VALUES(:name,:category, :url,:comment,sysdate());");
$stmt->bindValue(':name', $name, PDO::PARAM_STR); 
$stmt->bindValue(':category', $category, PDO::PARAM_STR);
$stmt->bindValue(':url', $url, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':comment', $comment, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$status = $stmt->execute();
//$name, $emailなどが:name, :emailに渡されて$stmtに入り、一番上の式で合体される。それをexecuteで実行する。

//４．データ登録処理後
if($status==false){
  sql_error();

}else{
  redirect("kadai_index.php");

}
?>
