<?php
//kadai_update.phpから作成
//1. POSTデータ取得(飛んできたのを受け取る)
$id = $_GET["id"];
var_dump($id);

//2. DB接続します
include("kadai_funcs.php");
$pdo = db_conn();


//３．データ登録SQL作成
//prepareはSQLを読む関数
$stmt = $pdo->prepare("DELETE FROM gs_bm_table WHERE id=:id");
$stmt->bindValue(':id', $id, PDO::PARAM_INT);  //Integer（数値の場合 PDO::PARAM_INT)
$status = $stmt->execute();

//４．データ登録処理後
if($status==false){
    sql_error();
}else{
  redirect("kadai_select.php");
}
?>
